//
//  lowLevel.h
//  
//
//  Created by Marcus Hall on 4/11/15.
//
//

#ifndef ____lowLevel__
#define ____lowLevel__

#include <stdio.h>

void writeCKIHigh(void);
void writeCKILow(void);
void writeSDIHigh(void);
void writeSDILow(void);
void PWMOut(uint8_t, uint8_t);

#endif /* defined(____lowLevel__) */
