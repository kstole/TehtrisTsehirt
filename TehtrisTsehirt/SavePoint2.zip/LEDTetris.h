//
//  LEDTetris.h
//  TehtrisTsehirt
//
//  Created by Kyler Stole on 3/4/16.
//  Copyright © 2016 Kyler Stole. All rights reserved.
//

#ifndef LEDTetris_h
#define LEDTetris_h

#include "TetrisSRS_Core.h" // defines H = 13
#include "LEDGridDriver.h" // defines H = 10

#endif /* LEDTetris_h */
