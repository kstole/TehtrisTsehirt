//
//  PlayTetris.h
//  TehtrisTsehirt
//
//  Created by Kyler Stole on 3/4/16.
//  Copyright © 2016 Kyler Stole. All rights reserved.
//

#ifndef PlayTetris_h
#define PlayTetris_h

#include <stdio.h>
#include "TetrisSRS_core.h"

#endif /* PlayTetris_h */
