//
//  PlayTetris.c
//  TehtrisTsehirt
//
//  Created by Kyler Stole on 3/4/16.
//  Copyright © 2016 Kyler Stole. All rights reserved.
//

#include "PlayTetris.h"

int main() {
    initTetris();
    do {
        newPiece();
        do {
            printArray();
            char c = 'p';
            //while ( getchar() != '\n' );
            while (1) {
                //c = fgetc(stdin);
                c = getchar();
                if (c == 'a')
                    moveLeft();
                else if (c == 'd')
                    moveRight();
                else if (c == 'w')
                    rotateCW();
                else if (c == 's')
                    drop();
                else break;
            }
            //sleep(1);
        } while (drop());
        checkRows();
    } while (!gameOver());
    showGameOver();

    return 0;
}