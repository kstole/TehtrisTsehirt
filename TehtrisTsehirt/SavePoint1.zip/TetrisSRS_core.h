//
//  tetris_srs.h
//  TehtrisTsehirt
//
//  Created by Kyler Stole on 2/29/16.
//  Copyright © 2016 Kyler Stole. All rights reserved.
//

#ifndef tetris_srs_h
#define tetris_srs_h

#define HI 10
#define W 8
#define H 13  // 10

extern uint8_t board[W][H];

void initTetris(void);

uint8_t play(void);

uint8_t showGameOver(void);

#endif /* tetris_srs_h */
