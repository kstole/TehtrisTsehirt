//
//  LEDGrid.h
//  TehtrisTsehirt
//
//  Created by Kyler Stole on 2/26/16.
//  Copyright © 2016 Kyler Stole. All rights reserved.
//

#ifndef LEDGrid_h
#define LEDGrid_h

#define CPU_PRESCALE(n) (CLKPR = 0x80, CLKPR = (n))
#define CPU_16MHz		0x00
#define CPU_8MHz		0x01
#define CPU_4MHz		0x02
#define CPU_2MHz		0x03
#define CPU_1MHz		0x04
#define CPU_500kHz	0x05
#define CPU_250kHz	0x06
#define CPU_125kHz	0x07
#define CPU_62kHz		0x08

#define HI 10
#define W 8
#define H 13  // 10

enum color {
	red = 0,
	green = 1,
	blue = 2
};

uint8_t displayColor(uint8_t color);

uint8_t selectColumns(uint8_t c, uint8_t x, uint8_t array[][8]);

uint8_t getButton(uint8_t but);

/**
 *  Translates the tetris board into the array for the LEDs.
 *
 *  @param array LED array
 */
void translate(uint8_t array[][W]);

//void _delay_ms(unsigned int);

#endif /* LEDGrid_h */
