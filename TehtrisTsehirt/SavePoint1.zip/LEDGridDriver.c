//
//  LEDGrid.c
//  TehtrisTsehirt
//
//  Created by Kyler Stole and Zachary Stark on 1/24/16.
//  Copyright (c) 2015 Kyler Stole and Zachary Stark. All rights reserved.
//

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include "LEDGrid.h"
#include "tetris_srs.h"

//char PORTB, PORTC, PORTD, PORTF, PINF, DDRB, DDRC, DDRD, DDRF, CLKPR;

// 0b[r][g][b]
uint8_t colors[8] = {
	0b000,
	0b110,
	0b100,
	0b011,
	0b111,
	0b010,
	0b101,
	0b001
};

uint8_t rowSelect[HI] = {
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000,
	0b00010000,
	0b00100000,
	0b01000000,
	0b10000000,
	0b00000000,	// managed by Port C
	0b00000000	// managed by Port C
};

//void _delay_ms(unsigned int time) {return;}

uint8_t displayColor(uint8_t color) {
	uint8_t f = PORTF & 0b00011111;
	
	f |= 1 << (5 + color);
	
	return f;
}

uint8_t selectColumns(uint8_t color, uint8_t row, uint8_t array[][8]) {
	uint8_t colorByte = 0x00;
	
	// Loop through columns
	for (uint8_t col = 7; col < W; col--) {
		if (colors[array[row][col]]>>color & 1) colorByte |= 1;
		if (col != 0) colorByte <<= 1;
	}
	
	return colorByte;
}

uint8_t isHeld[3] = {0,0,0};
uint8_t getButton(uint8_t but) {
	if (PINF & 1) isHeld[1] = 0;
	else if (but == 1 && !isHeld[1]) {
		isHeld[1] = 1;
		return 1;
	}
	if (PINF & 2) isHeld[2] = 0;
	else if (but == 2 && !isHeld[2]) {
		isHeld[2] = 1;
		return 1;
	}
	if (PINF & 16) isHeld[0] = 0;
	else if (but == 0 && !isHeld[0]) {
		isHeld[0] = 1;
		return 1;
	}
	return 0;
}

/* Translates the tetris board into the array for the LEDs */
void translate(uint8_t array[][W]) {
	for (uint8_t i = 0; i < HI; i++)
		for (uint8_t j = 0; j < W; j++)
			array[i][j] = board[j][H-1-i];
}

int main(void) {
	CPU_PRESCALE(CPU_16MHz);
	
	/* insert your hardware initialization here */
	
 /**
	*  Port B					- select columns
	*  Port D					- select row[0:7]
	*  Port C[7:6]		- select row[8:9]
	*  Port F[7:5]		- select color
	*  Port F[4,1,0]	- buttons
	*/
	
	// Data Direction Registers
	DDRB = 0xFF;
	DDRD = 0xFF;
	DDRC = 0xFF;
	DDRF = 0b11100000;
	
	// Ports
	PORTB = 0x00;
	PORTD = 0x00;
	PORTC = 0x00;
	PORTF = 0b00010011;
	
	uint8_t array[10][8] = {
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0}
	};
	
	initTetris();
	
	/* Randomize seed */
	uint8_t manualSeed = 0;
	while (1) {
		manualSeed++;
		if (getButton(0) || getButton(1) || getButton(2) || getButton(3)) {
			srand(manualSeed);
			break;
		}
	}
	
	while (1) {
		if (play()) break;
		
		// Translate Tetris board into array for use w/ LED grid
		translate(array);
		
		// Loop through rows
		for (uint8_t row = 0; row < HI; row++) {
			// Set row
			PORTD = rowSelect[row];
			
			// Correction for rows 9 and 10
			switch (row) {
				case 8:
					PORTC |= 0b01000000;
					break;
				case 9:
					PORTC &= 0b00111111;
					PORTC |= 0b10000000;
				default:
					PORTC &= 0b00111111;
					break;
			}
			
			// Loop through all colors
			for (uint8_t color = 0; color < 3; color++) {
				// Select color to display
				PORTF = displayColor(color);
				
				// Select columns that display the color
				PORTB = selectColumns(color, row, array);
				
				// Display each color for 0.5 ms
				_delay_ms(0.5);
			}
		}
		PORTB = 0;
	}
	
	while (1) {
		if (showGameOver()) break;
		
		// Translate Tetris scoreboard into array for use w/ LED grid
		translate(array);
		
		// Loop through rows
		for (uint8_t row = 0; row < HI; row++) {
			// Set row
			PORTD = rowSelect[row];
			
			// Correction for rows 9 and 10
			switch (row) {
				case 8:
					PORTC |= 0b01000000;
					break;
				case 9:
					PORTC &= 0b00111111;
					PORTC |= 0b10000000;
				default:
					PORTC &= 0b00111111;
					break;
			}
			
			// Loop through colors
			for (uint8_t color = 0; color < 3; color++) {
				// Select color to display
				PORTF = displayColor(color);
				
				// Select columns that display the color
				PORTB = selectColumns(color, row, array);
				
				// Display each color for 0.5 ms
				_delay_ms(0.5);
			}
		}
		PORTB = 0;
	}
	
	return 0;   /* never reached */
}
